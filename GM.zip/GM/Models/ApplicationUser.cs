﻿using Microsoft.AspNetCore.Identity;

namespace GuptaMedicalCoreWebAPI22.Models
{
    public class ApplicationUser: IdentityUser
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? AppName { get; set; }
    }
}
