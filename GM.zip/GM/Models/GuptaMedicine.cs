﻿using System.ComponentModel.DataAnnotations.Schema;

namespace GuptaMedicalCoreWebAPI22.Models
{
    [Table("GuptaMedicine", Schema = "dbo")]
    public class GuptaMedicine
    {
        public int Id { get; set; }
        public string? OrderType { get; set; }
        public string?   FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Contact { get; set; }
        public string? AlternateContact { get; set; }
        public string? Address { get; set; }
        public string? Prescription { get; set; }
        public string? Gender { get; set; }
        public string? HealthProblem { get; set; }
        public string? MedicineRequired { get; set; }


    }
}
