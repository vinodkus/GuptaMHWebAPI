﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GuptaMedicalCoreWebAPI22.Data;
using GuptaMedicalCoreWebAPI22.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Hosting.Internal;
using Microsoft.Extensions.Logging;
using System.Net;
using Microsoft.AspNetCore.Authorization;

namespace GuptaMedicalCoreWebAPI22.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class GuptaMedicinesController : ControllerBase
    {
        private readonly GuptaDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public GuptaMedicinesController(GuptaDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        // GET: api/GuptaMedicines
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GuptaMedicine>>> GetGuptaMedicine()
        {
          if (_context.GuptaMedicine == null)
          {
              return NotFound();
          }
            return await _context.GuptaMedicine.ToListAsync();
        }

        // GET: api/GuptaMedicines/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GuptaMedicine>> GetGuptaMedicine(int id)
        {
          if (_context.GuptaMedicine == null)
          {
              return NotFound();
          }
            var guptaMedicine = await _context.GuptaMedicine.FindAsync(id);

            if (guptaMedicine == null)
            {
                return NotFound();
            }

            return guptaMedicine;
        }

        // PUT: api/GuptaMedicines/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutGuptaMedicine(int id, GuptaMedicine guptaMedicine)
        {
            if (id != guptaMedicine.Id)
            {
                return BadRequest();
            }

            _context.Entry(guptaMedicine).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GuptaMedicineExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/GuptaMedicines
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<GuptaMedicine>> PostGuptaMedicine(GuptaMedicine guptaMedicine)
        {
          if (_context.GuptaMedicine == null)
          {
              return Problem("Entity set 'GuptaDbContext.GuptaMedicine'  is null.");
          }
            _context.GuptaMedicine.Add(guptaMedicine);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetGuptaMedicine", new { id = guptaMedicine.Id }, guptaMedicine);
        }

        // DELETE: api/GuptaMedicines/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGuptaMedicine(int id)
        {
            if (_context.GuptaMedicine == null)
            {
                return NotFound();
            }
            var guptaMedicine = await _context.GuptaMedicine.FindAsync(id);
            if (guptaMedicine == null)
            {
                return NotFound();
            }

            _context.GuptaMedicine.Remove(guptaMedicine);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool GuptaMedicineExists(int id)
        {
            return (_context.GuptaMedicine?.Any(e => e.Id == id)).GetValueOrDefault();
        }
        [HttpPost("UploadCustomerFile")]
        public async Task<ActionResult> UploadCustomerFile()
        {
            bool Results = false;
            var msg = "NA";
            try
            {
                var _uplodedFiles = Request.Form.Files;
                foreach (IFormFile source in _uplodedFiles)
                {
                    string Filename = source.FileName;
                    string Filepath = GetFilePath();
                    if(!System.IO.Directory.Exists(Filename))
                    {
                        System.IO.Directory.CreateDirectory(Filepath);
                    }
                    string imagepath = Filepath + Filename;
                    if(System.IO.File.Exists(imagepath))
                    {
                        System.IO.File.Delete(imagepath);
                    }
                    using (FileStream stream=System.IO.File.Create(imagepath))
                    {
                        await source.CopyToAsync(stream);
                        Results = true;
                        msg = "Done";
                    }
                }                
            }
            catch (Exception ex)
            {
                msg = ex.Message.ToString();
            }
            return Ok(msg);
        }
        [NonAction]
        private string GetFilePath()
        {
            return this._environment.WebRootPath + "\\Uploads\\";
        }
        
    }
}
