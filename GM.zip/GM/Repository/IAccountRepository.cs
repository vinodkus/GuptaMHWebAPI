﻿using GuptaMedicalCoreWebAPI22.Models;
using Microsoft.AspNetCore.Identity;

namespace GuptaMedicalCoreWebAPI22.Repository
{
    public interface IAccountRepository    {
         Task<IdentityResult> SignupAsync(SignUpModel signUpModel);
        Task<string> LoginAsync(SignInModel signInModel);
    }
}
